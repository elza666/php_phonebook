<?php

$seznam = array(
  1 => array(
    'jmeno' => 'Franta',
    'prijmeni' => 'Vomáčka',
    'telefon' => '541546589',
    'telefon2' => '541546589',
  ),
  2 => array( 
    'jmeno' => 'John',
    'prijmeni' => 'Doe',
    'telefon' => '448678878',
    'telefon2' => '541546589',
  ),
  3 => array(
    'jmeno' => 'Donald',
    'prijmeni' => 'Duck',
    'telefon' => '131313131',
    'telefon2' => '541546589',
  ),
  4 => array(
    'jmeno' => 'Paul',
    'prijmeni' => 'Hewson',
    'telefon' => '979797979',
    'telefon2' => '541546589',
  ),
  5 => array(
    'jmeno' => 'Christopher',
    'prijmeni' => 'Nolan',
    'telefon' => '132456488',
    'telefon2' => '541546589',
  ),
  6 => array(
    'jmeno' => 'Ridley',
    'prijmeni' => 'Scott',
    'telefon' => '789465132',
    'telefon2' => '541546589',
  ),
  7 => array(
    'jmeno' => 'Karkulka',
    'prijmeni' => 'Cervená',
    'telefon' => '12',
    'telefon2' => '',
  ),
);
