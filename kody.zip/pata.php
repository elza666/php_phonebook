  <div id="footer">
    <div id="footer-in">
    
    <div class="cleaner">&nbsp;</div>

    </div>
  </div> <!-- Footer end -->

</div> <!-- Wrapper end -->
</body>

</html>

