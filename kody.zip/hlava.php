<?php
//require __DIR__ . '/../../Nette/Nette/loader.php';
//\Nette\Diagnostics\Debugger::enable();

require_once __DIR__ . '/filter.php';
require __DIR__ . '/seznam.php';

?>


<!doctype html>
<html lang="cs">

    <head>
        <meta charset="UTF-8" />
        <link rel="stylesheet" href="css/style.css" type="text/css" />
        <title>Telefonní seznam</title>
    </head>
    
    <body id="top">
    <div id="wrapper">

          <!-- Header -->
            <div id="header">
              <h1><a href="/">Telefonní seznam</a></h1>
              <p class="title">školní úloha</p>
            </div>
          <!-- Header end -->

        


